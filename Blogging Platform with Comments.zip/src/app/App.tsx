import { useState, useEffect } from "react";
import {
  PenLine, LogIn, LogOut, Plus, Edit2, Trash2,
  MessageCircle, Heart, Search, X, Menu,
  ChevronLeft, Clock, Eye, AlertCircle,
  LayoutDashboard, FileText, Hash, ArrowRight,
  BookOpen, Share2, Calendar,
} from "lucide-react";
import { toast, Toaster } from "sonner";

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  bio: string;
  joinedAt: string;
}

interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
  likes: number;
  likedBy: string[];
}

interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  authorId: string;
  authorName: string;
  category: string;
  tags: string[];
  image: string;
  createdAt: string;
  updatedAt: string;
  views: number;
  likes: number;
  likedBy: string[];
  comments: Comment[];
  featured: boolean;
}

type View = "home" | "login" | "register" | "post" | "create" | "edit" | "dashboard";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

const CATEGORIES = ["Technology", "Travel", "Food", "Architecture", "Science", "Lifestyle"];

const CATEGORY_COLORS: Record<string, string> = {
  Technology: "bg-indigo-100 text-indigo-700",
  Travel: "bg-emerald-100 text-emerald-700",
  Food: "bg-orange-100 text-orange-700",
  Architecture: "bg-slate-200 text-slate-700",
  Science: "bg-blue-100 text-blue-700",
  Lifestyle: "bg-rose-100 text-rose-700",
};

const AVATAR_PALETTE = ["#c8392b", "#1a6b5c", "#2c5282", "#7b341e", "#553c9a", "#2d6a4f", "#9c5a3c", "#1a5276"];

// ─── INITIAL DATA ─────────────────────────────────────────────────────────────

const INITIAL_USERS: User[] = [
  {
    id: "u1",
    name: "Sarah Mitchell",
    email: "sarah@inkwell.com",
    password: "password123",
    bio: "Senior technology writer covering AI, remote work, and digital culture. Previously at The Atlantic and Wired. Based in San Francisco.",
    joinedAt: "2023-09-15",
  },
  {
    id: "u2",
    name: "Marcus Chen",
    email: "marcus@inkwell.com",
    password: "password123",
    bio: "Travel journalist and photographer exploring Southeast Asia, one story at a time. Author of 'Roads Less Mapped'. Currently in Hanoi.",
    joinedAt: "2023-11-02",
  },
];

const INITIAL_POSTS: Post[] = [
  {
    id: "post-1",
    title: "The Future of Remote Work: How Technology Is Reshaping Professional Life",
    excerpt: "Five years after the great remote work experiment began, we are finally starting to understand what was gained, what was lost, and what the hybrid future looks like for knowledge workers worldwide.",
    content: `The spring of 2020 triggered the largest workplace experiment in human history. Within weeks, millions of knowledge workers were asked to reconstruct their professional lives inside their homes — often without adequate equipment, dedicated space, or psychological preparation. Now, half a decade on, we can begin to make sense of what actually happened.

What emerged from that chaotic transition was not just a new way of working, but a profound renegotiation of the social contract between employers and employees. Workers who had spent years commuting discovered that their productivity did not depend on physical proximity to colleagues. Managers who had built careers around visible control found themselves having to trust output over observation.

The technology that enabled this shift — Slack, Zoom, Notion, Figma, GitHub — became the connective tissue of distributed organizations. But these tools also revealed something that office life had always papered over: the enormous amount of invisible labor that goes into maintaining professional relationships. Water-cooler conversations, hallway discussions, and the incidental cross-pollination of ideas all required deliberate replacement.

Companies that thrived in this environment tended to share several characteristics. They had invested heavily in asynchronous communication norms, treating documentation as a first-class product. They had rebuilt their management practices around outcomes rather than activity. And critically, they had given employees genuine autonomy over when and how they worked — not just where.

The hybrid model that most large companies have now settled on is, in many ways, the worst of both worlds if implemented poorly. Flying workers into offices one or two days a week for "collaboration" often produces the opposite: people sit on video calls in conference rooms, having the same meetings they would have had from home. The companies doing hybrid well are ruthless about what requires physical presence and protect remote time for deep work.

What is clear is that we are not returning to the office of 2019. The genie is out of the bottle. Workers who proved they could deliver results from their living rooms now have concrete data to support their preference for flexibility. And the talent market — still tight in many technical fields — gives them the leverage to demand it.`,
    authorId: "u1",
    authorName: "Sarah Mitchell",
    category: "Technology",
    tags: ["remote-work", "technology", "productivity", "future-of-work"],
    image: "https://images.unsplash.com/photo-1622131815526-eaae1e615381?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-11-14T09:30:00Z",
    updatedAt: "2024-11-14T09:30:00Z",
    views: 4821,
    likes: 237,
    likedBy: [],
    comments: [
      {
        id: "c1",
        postId: "post-1",
        authorId: "u2",
        authorName: "Marcus Chen",
        content: "Really thoughtful piece, Sarah. I have seen this play out firsthand — companies that use hybrid as a policy rather than a practice are struggling the most. The ones doing it well have basically rebuilt their culture from scratch.",
        createdAt: "2024-11-14T11:45:00Z",
        likes: 12,
        likedBy: [],
      },
      {
        id: "c2",
        postId: "post-1",
        authorId: "u1",
        authorName: "Sarah Mitchell",
        content: "Exactly, Marcus. Culture is the key variable that most productivity studies completely ignore. You cannot measure belonging in a spreadsheet.",
        createdAt: "2024-11-14T12:20:00Z",
        likes: 8,
        likedBy: [],
      },
    ],
    featured: true,
  },
  {
    id: "post-2",
    title: "Hidden Gems of Southeast Asia: A 30-Day Journey Through Vietnam and Cambodia",
    excerpt: "Beyond the tourist trail lies a Southeast Asia of extraordinary depth — ancient temple complexes at dawn, floating villages with centuries of history, and roadside kitchens that put Michelin restaurants to shame.",
    content: `I left Hanoi on a Tuesday in early February, on a night train heading south. The kind of trip I had been planning for two years, postponed twice, finally happening. Thirty days, no fixed itinerary after the first week, one small bag, and the standing instruction from my editor to come back with something true.

The north of Vietnam greets you like a cold wash of water to the face. Sapa's rice terraces in the fog, the Hmong women in their embroidered indigo jackets at the market in Bac Ha, the way the road to Ha Giang climbs into mist so thick you lose sight of the valley below. This is not a country that gives itself up easily. You have to earn it with time and patience.

In Hoi An, I spent four days doing almost nothing. The ancient town — a UNESCO World Heritage Site that somehow has not been completely hollowed out by tourism — rewards stillness. The lantern-lit streets at dusk, the tailors who have been cutting fabric for three generations, the morning market where locals buy their vegetables before the tourist cafes open. The secret is arriving before 7am, before the tour buses.

Cambodia announced itself differently. The border crossing at Bavet is chaotic and bureaucratic in the way that reminds you how recently this country was broken. But an hour from the border, you are in Phnom Penh — a city in the middle of an awkward, exhilarating adolescence. The food scene alone is worth the journey: modern Khmer kitchens reinterpreting forgotten recipes, rooftop bars overlooking the Mekong, and the Cambodian BBQ restaurants along the riverfront that stay open until 3am.

Angkor is, despite everything you have heard and everything the crowds might suggest, genuinely transcendent at dawn. I arrived at Angkor Wat at 5:30am on a Saturday, stood in the reflecting pool with maybe a dozen other people, and watched the sun come up behind the five towers. No photograph I took does justice to that moment. Some things resist compression.

The trip ended, as these things do, too soon. I came back with 800 photographs, 45 pages of notes, and a profound conviction that Southeast Asia reveals itself only to those who are not in a hurry.`,
    authorId: "u2",
    authorName: "Marcus Chen",
    category: "Travel",
    tags: ["travel", "southeast-asia", "vietnam", "cambodia", "adventure"],
    image: "https://images.unsplash.com/photo-1661343331655-2ac8fb456496?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-11-08T14:00:00Z",
    updatedAt: "2024-11-08T14:00:00Z",
    views: 6102,
    likes: 389,
    likedBy: [],
    comments: [
      {
        id: "c3",
        postId: "post-2",
        authorId: "u1",
        authorName: "Sarah Mitchell",
        content: "Marcus, the description of Angkor at dawn made me immediately start looking at flights. The line 'Some things resist compression' is going in my notebook.",
        createdAt: "2024-11-08T16:30:00Z",
        likes: 24,
        likedBy: [],
      },
    ],
    featured: false,
  },
  {
    id: "post-3",
    title: "Mastering French Cuisine at Home: From Boeuf Bourguignon to Perfect Creme Brulee",
    excerpt: "French cooking has a reputation for intimidating complexity that is mostly undeserved. The real secrets are patience, quality ingredients, and understanding why the technique exists before you try to follow it.",
    content: `Julia Child said the secret of French cooking was butter. This is partially true, and also misses the point. The real secret is time — the willingness to reduce a sauce until it is thick and glossy and coats the back of a spoon, to let a braise go low and slow until the collagen melts into the braising liquid, to temper your eggs into a custard without rushing.

Boeuf Bourguignon is the first French dish most home cooks attempt, and it rewards patience in every stage. The key step that most recipes undersell is the browning of the beef. This is not optional. You need high heat, dry meat (pat it down thoroughly), and the patience to leave each piece alone until it develops a dark, mahogany crust. That Maillard reaction is where half your flavor lives. Rushing this step produces grey, stewed meat rather than the dark, complex braise Julia intended.

The wine matters too, though not in the way people fear. You do not need an expensive Burgundy — Cotes du Rhone or a decent Pinot Noir will do. What you do need is wine you would actually drink. The cooking concentrates flavors, so poor wine produces a poor sauce.

Creme brulee operates on a different logic entirely. Here, the enemy is impatience in the oven. The custards should bake in a water bath at 325F until they are just barely set — still with a slight wobble in the center, like a firm Jello. Over-baked creme brulee is grainy and sad; perfectly baked is silky and rich in a way that is hard to forget.

The caramelization at the end is the theatrical part, and it is much less dangerous than it looks. A kitchen torch, held four to six inches from the surface, moved in concentric circles. The sugar should melt, then bubble, then go amber, then dark amber. Stop before it smells burnt. Let it cool for a minute before you crack it — that is when the glass-like surface sets up.

French cooking, done properly, is a meditation on respect: for ingredients, for technique, and for the people you are feeding.`,
    authorId: "u2",
    authorName: "Marcus Chen",
    category: "Food",
    tags: ["food", "french-cuisine", "cooking", "recipes", "technique"],
    image: "https://images.unsplash.com/photo-1636647511729-6703539ba71f?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-10-29T10:15:00Z",
    updatedAt: "2024-10-29T10:15:00Z",
    views: 3847,
    likes: 196,
    likedBy: [],
    comments: [],
    featured: false,
  },
  {
    id: "post-4",
    title: "Sustainable Architecture's New Wave: Buildings That Work With Nature",
    excerpt: "A new generation of architects is rejecting the glass-and-steel modernism that defined the 20th century, designing structures that generate energy, filter water, and support biodiversity rather than depleting it.",
    content: `The Bosco Verticale towers in Milan — residential buildings whose balconies are planted with over 900 trees and 20,000 plants — are usually where conversations about biophilic architecture start. But they are also, in some ways, where the conversation should end: expensive, high-maintenance, and accessible only to the wealthy. Real sustainable architecture has to do more than look striking in architectural photography.

The more interesting work is happening at smaller scales and in less photogenic places. In Singapore, where land is scarce and climate change means increasingly intense rainfall, building codes now mandate green roofs on structures over a certain size. The Gardens by the Bay complex has become a model for how urban green space can double as climate infrastructure, absorbing stormwater that would otherwise overwhelm drainage systems.

Mass timber construction is perhaps the most significant structural shift in architecture since reinforced concrete. Cross-laminated timber (CLT) and glulam beams allow architects to build high-rises that are structurally similar to steel-framed buildings but store carbon rather than emitting it during production. The T3 tower in Minneapolis — twelve stories of mass timber — is both beautiful and a provocative demonstration of what post-petroleum construction might look like.

What is most exciting about this new wave is its integration with local ecology. Rather than imposing a universal modernist aesthetic on every site, architects are asking what the land wants: what materials are available nearby, what climate conditions will the building need to respond to, what species should the building support. In this sense, the best sustainable buildings are intensely specific — deeply local in a way that glass curtain walls can never be.

The challenge is economics. Sustainable building materials and techniques still carry a cost premium that the market has not fully absorbed. Green buildings typically sell for 5-10% more and rent for a similar premium, which is enough to make the economics work in high-value markets but not in affordable housing. Solving that gap is the real work of the next decade.`,
    authorId: "u1",
    authorName: "Sarah Mitchell",
    category: "Architecture",
    tags: ["architecture", "sustainability", "design", "urban-planning", "climate"],
    image: "https://images.unsplash.com/photo-1643875405028-09443a0552ed?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-10-20T08:45:00Z",
    updatedAt: "2024-10-20T08:45:00Z",
    views: 2934,
    likes: 158,
    likedBy: [],
    comments: [],
    featured: false,
  },
  {
    id: "post-5",
    title: "The Science of Sleep: Why Your Brain Needs More Than Eight Hours",
    excerpt: "Neuroscience has upended everything we thought we knew about sleep in the past decade. The research is alarming, fascinating, and carries urgent implications for how modern society structures time.",
    content: `We have known for decades that sleep matters. What we did not understand until recently was how desperately, mechanically, chemically it matters — and how badly we have arranged modern life around its violation.

Matthew Walker's research at UC Berkeley has produced some of the most important and troubling findings in contemporary neuroscience. The glymphatic system — the brain's waste-clearance mechanism — operates almost exclusively during deep sleep, flushing out metabolic byproducts including the amyloid plaques associated with Alzheimer's disease. Every night you sleep five hours instead of eight, you are making a withdrawal from an account whose balance you cannot check.

The standard advice — eight hours — is itself a simplification. Sleep is not a single state but a series of cycles, each around 90 minutes, cycling through light sleep, deep slow-wave sleep, and REM. The distribution of these stages across the night is not even: deep sleep is front-loaded, REM is back-loaded. This means that cutting your sleep by two hours does not just reduce your total sleep by 25% — it disproportionately eliminates REM sleep, which appears to be essential for emotional regulation, memory consolidation, and creative thinking.

The implications for work culture are severe. A person who has slept six hours for two weeks shows cognitive impairment equivalent to 24 hours of total sleep deprivation — and critically, they do not know it. The subjective sense of impairment fades faster than the objective impairment itself. We become confident in our compromised state.

Caffeine, the world's most popular psychoactive drug, masks but does not resolve sleep debt. It blocks adenosine receptors — the molecules that signal sleepiness — but does not stop adenosine accumulation. When caffeine wears off, the adenosine floods back. The sleep debt remains.

The path forward is not simple, but it starts with treating sleep as a legitimate biological need rather than a productivity variable to be optimized away.`,
    authorId: "u1",
    authorName: "Sarah Mitchell",
    category: "Science",
    tags: ["science", "sleep", "neuroscience", "health", "wellness"],
    image: "https://images.unsplash.com/photo-1713880304260-c6e13a9a8a05?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-10-11T16:00:00Z",
    updatedAt: "2024-10-11T16:00:00Z",
    views: 5218,
    likes: 312,
    likedBy: [],
    comments: [],
    featured: false,
  },
  {
    id: "post-6",
    title: "Urban Foraging: How to Find Wild Ingredients Growing in Your City",
    excerpt: "Every city is a garden if you know where to look. From Japanese knotweed to elderflower and wood sorrel, edible plants grow in the margins of urban life, waiting to be noticed.",
    content: `I found my first chanterelle mushroom growing from the base of a linden tree in Prospect Park, Brooklyn, on an October afternoon that smelled of wet leaves and someone's distant barbecue. I had been walking past that tree for three years without seeing it. Once I learned to look, I could not stop.

Urban foraging sits at an intersection that food culture rarely explores: between the wildness that survives in cities and the domesticated relationship most of us have with food. Most city dwellers are three or four generations removed from any practical knowledge of wild plants. We have outsourced that knowledge entirely to grocery stores, and something important has been lost in the transaction.

The easiest plants to start with are the ones that most people call weeds. Purslane — that low, succulent plant that grows in sidewalk cracks and neglected garden beds — is delicious raw in salads, with a texture like watercress and a slight lemony flavor. It is also one of the most nutritionally dense leafy greens in existence, with omega-3 fatty acid levels that rival fatty fish.

Wood sorrel looks like three-leafed clover and tastes intensely of lemon drops. It grows in the shaded edges of parks, along fences, and in any slightly moist soil with partial shade. Children, if you show them, immediately love it — the sourness is a revelation.

Japanese knotweed, which grows explosively along riverbanks and disturbed urban soils, is deeply invasive and almost impossible to eradicate. It is also, when harvested young in early spring, extraordinarily delicious — similar in flavor and texture to rhubarb, excellent in chutneys, pies, and braised savory dishes. Eating it is a small act of ecological justice.

A few crucial rules: forage only in places where you are certain no pesticides or herbicides have been applied. Stay away from major roads. Identify with certainty before eating. And take only what you need — the plants need to seed and the ecosystem needs to feed other creatures.`,
    authorId: "u2",
    authorName: "Marcus Chen",
    category: "Lifestyle",
    tags: ["lifestyle", "foraging", "urban", "food", "sustainability", "nature"],
    image: "https://images.unsplash.com/photo-1682416480878-cfe14c646c6b?w=800&h=500&fit=crop&auto=format",
    createdAt: "2024-09-28T11:30:00Z",
    updatedAt: "2024-09-28T11:30:00Z",
    views: 2156,
    likes: 124,
    likedBy: [],
    comments: [],
    featured: false,
  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function uid() { return Math.random().toString(36).substr(2, 9); }

function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function timeAgo(d: string) {
  const diff = Date.now() - new Date(d).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return fmtDate(d);
}

function readTime(content: string) { return Math.max(1, Math.ceil(content.split(/\s+/).length / 200)); }
function getInitials(name: string) { return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2); }
function avatarColor(name: string) { return AVATAR_PALETTE[name.charCodeAt(0) % AVATAR_PALETTE.length]; }

function loadState<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch { return fallback; }
}

// ─── AVATAR ───────────────────────────────────────────────────────────────────

function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  return (
    <div
      className="rounded-full flex items-center justify-center text-white font-semibold shrink-0"
      style={{ width: size, height: size, backgroundColor: avatarColor(name), fontSize: Math.floor(size * 0.38) }}
    >
      {getInitials(name)}
    </div>
  );
}

// ─── BADGE ────────────────────────────────────────────────────────────────────

function Badge({ category }: { category: string }) {
  const cls = CATEGORY_COLORS[category] ?? "bg-gray-100 text-gray-700";
  return (
    <span className={`inline-block text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full ${cls}`}>
      {category}
    </span>
  );
}

// ─── POST CARD ────────────────────────────────────────────────────────────────

function PostCard({ post, onOpen }: { post: Post; onOpen: (id: string) => void }) {
  return (
    <article
      className="group bg-card rounded-xl overflow-hidden border border-border hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 cursor-pointer"
      onClick={() => onOpen(post.id)}
    >
      <div className="aspect-[16/10] overflow-hidden bg-muted">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      <div className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Badge category={post.category} />
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock size={10} />
            {readTime(post.content)} min read
          </span>
        </div>
        <h3 className="font-display text-[1.05rem] font-semibold leading-snug mb-2 text-foreground group-hover:text-accent transition-colors line-clamp-2">
          {post.title}
        </h3>
        <p className="text-[13px] text-muted-foreground leading-relaxed mb-4 line-clamp-2">
          {post.excerpt}
        </p>
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <div className="flex items-center gap-2">
            <Avatar name={post.authorName} size={26} />
            <span className="text-[12px] font-medium text-foreground">{post.authorName}</span>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1"><Heart size={10} />{post.likes}</span>
            <span className="flex items-center gap-1"><MessageCircle size={10} />{post.comments.length}</span>
          </div>
        </div>
      </div>
    </article>
  );
}

// ─── COMMENT ITEM ─────────────────────────────────────────────────────────────

function CommentItem({
  comment, user, onLike, onDelete,
}: {
  comment: Comment; user: User | null;
  onLike: () => void; onDelete: () => void;
}) {
  const isAuthor = user?.id === comment.authorId;
  const isLiked = user ? comment.likedBy.includes(user.id) : false;
  return (
    <div className="flex gap-3">
      <Avatar name={comment.authorName} size={34} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">{comment.authorName}</span>
            <span className="text-xs text-muted-foreground">{timeAgo(comment.createdAt)}</span>
          </div>
          {isAuthor && (
            <button onClick={onDelete} className="text-muted-foreground hover:text-red-600 transition-colors p-1">
              <Trash2 size={12} />
            </button>
          )}
        </div>
        <p className="text-sm text-foreground/85 leading-relaxed mb-2">{comment.content}</p>
        <button
          onClick={onLike}
          className={`flex items-center gap-1 text-xs transition-colors ${isLiked ? "text-red-500" : "text-muted-foreground hover:text-foreground"}`}
        >
          <Heart size={11} fill={isLiked ? "currentColor" : "none"} />
          {comment.likes > 0 && comment.likes}
        </button>
      </div>
    </div>
  );
}

// ─── CONFIRM MODAL ────────────────────────────────────────────────────────────

function ConfirmModal({
  title, description, onConfirm, onCancel, confirmLabel = "Delete",
}: {
  title: string; description: string;
  onConfirm: () => void; onCancel: () => void; confirmLabel?: string;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center shrink-0">
            <AlertCircle size={18} className="text-red-600" />
          </div>
          <h3 className="font-semibold text-base">{title}</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-5 pl-[52px]">{description}</p>
        <div className="flex gap-2 justify-end">
          <button
            onClick={onCancel}
            className="text-sm px-4 py-2 border border-border rounded-lg hover:bg-muted transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="text-sm px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── NAVBAR ───────────────────────────────────────────────────────────────────

function Navbar({ user, nav, onLogout }: { user: User | null; nav: (v: View) => void; onLogout: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => { nav("home"); setMobileOpen(false); }}
          className="flex items-center gap-2 hover:opacity-75 transition-opacity"
        >
          <PenLine size={18} className="text-accent" />
          <span className="font-display text-xl font-bold tracking-tight">Inkwell</span>
        </button>

        <nav className="hidden md:flex items-center gap-5">
          <button
            onClick={() => nav("home")}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Stories
          </button>
          {user ? (
            <>
              <button
                onClick={() => nav("dashboard")}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
              >
                <LayoutDashboard size={13} />
                Dashboard
              </button>
              <button
                onClick={() => nav("create")}
                className="flex items-center gap-1.5 text-sm font-medium bg-foreground text-primary-foreground px-4 py-2 rounded-full hover:opacity-85 transition-opacity"
              >
                <Plus size={13} />
                Write a Story
              </button>
              <div className="flex items-center gap-2 pl-1 border-l border-border">
                <Avatar name={user.name} size={30} />
                <button
                  onClick={onLogout}
                  title="Sign out"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <LogOut size={15} />
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                onClick={() => nav("login")}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => nav("register")}
                className="text-sm font-medium bg-foreground text-primary-foreground px-4 py-2 rounded-full hover:opacity-85 transition-opacity"
              >
                Get Started
              </button>
            </>
          )}
        </nav>

        <button
          className="md:hidden p-1.5 text-foreground"
          onClick={() => setMobileOpen(o => !o)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-background/98 px-4 py-4 flex flex-col gap-1">
          {user && (
            <div className="flex items-center gap-2 pb-3 mb-2 border-b border-border">
              <Avatar name={user.name} size={32} />
              <div>
                <div className="text-sm font-semibold">{user.name}</div>
                <div className="text-xs text-muted-foreground">{user.email}</div>
              </div>
            </div>
          )}
          <button onClick={() => { nav("home"); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors">Stories</button>
          {user ? (
            <>
              <button onClick={() => { nav("dashboard"); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors">Dashboard</button>
              <button onClick={() => { nav("create"); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors">Write a Story</button>
              <button onClick={() => { onLogout(); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors text-muted-foreground mt-1">Sign Out</button>
            </>
          ) : (
            <>
              <button onClick={() => { nav("login"); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors">Sign In</button>
              <button onClick={() => { nav("register"); setMobileOpen(false); }} className="text-sm text-left py-2 px-2 rounded hover:bg-muted transition-colors font-medium">Get Started</button>
            </>
          )}
        </div>
      )}
    </header>
  );
}

// ─── HOME VIEW ────────────────────────────────────────────────────────────────

function HomeView({
  posts, user, nav, onOpenPost,
}: {
  posts: Post[]; user: User | null; nav: (v: View) => void; onOpenPost: (id: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const featuredPost = posts.find(p => p.featured) || posts[0];

  const filteredPosts = posts
    .filter(p => p.id !== featuredPost?.id)
    .filter(p => !activeCategory || p.category === activeCategory)
    .filter(p =>
      !search ||
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.excerpt.toLowerCase().includes(search.toLowerCase()) ||
      p.authorName.toLowerCase().includes(search.toLowerCase())
    );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero / Featured Post */}
      {featuredPost && (
        <section
          className="relative overflow-hidden cursor-pointer group"
          style={{ height: "clamp(400px, 55vh, 600px)" }}
          onClick={() => onOpenPost(featuredPost.id)}
        >
          <img
            src={featuredPost.image}
            alt={featuredPost.title}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
          <div className="absolute top-4 left-6">
            <span className="text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full bg-accent text-white">
              Featured
            </span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 px-6 sm:px-10 lg:px-16 pb-8 sm:pb-12 max-w-4xl">
            <Badge category={featuredPost.category} />
            <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white mt-3 mb-3 leading-tight">
              {featuredPost.title}
            </h1>
            <p className="text-white/75 text-sm sm:text-base mb-5 max-w-2xl line-clamp-2 leading-relaxed">
              {featuredPost.excerpt}
            </p>
            <div className="flex items-center gap-4 text-white/65 text-sm">
              <div className="flex items-center gap-2">
                <Avatar name={featuredPost.authorName} size={26} />
                <span className="font-medium text-white/80">{featuredPost.authorName}</span>
              </div>
              <span>·</span>
              <span>{fmtDate(featuredPost.createdAt)}</span>
              <span>·</span>
              <span>{readTime(featuredPost.content)} min read</span>
            </div>
          </div>
        </section>
      )}

      {/* Main content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        {/* Search + Category Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-9">
          <div className="relative max-w-xs w-full">
            <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search stories..."
              className="w-full pl-9 pr-8 py-2.5 text-sm border border-border rounded-full bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent transition-all"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X size={13} />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setActiveCategory(null)}
              className={`text-xs px-3.5 py-1.5 rounded-full font-medium transition-colors ${!activeCategory ? "bg-foreground text-primary-foreground" : "border border-border text-muted-foreground hover:text-foreground hover:border-foreground/30"}`}
            >
              All
            </button>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(activeCategory === cat ? null : cat)}
                className={`text-xs px-3.5 py-1.5 rounded-full font-medium transition-colors ${activeCategory === cat ? "bg-foreground text-primary-foreground" : "border border-border text-muted-foreground hover:text-foreground hover:border-foreground/30"}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Section header */}
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="font-display text-2xl font-bold">
            {activeCategory || search ? (activeCategory || "Search Results") : "Latest Stories"}
          </h2>
          <span className="text-sm text-muted-foreground">
            {filteredPosts.length} {filteredPosts.length === 1 ? "story" : "stories"}
          </span>
        </div>

        {filteredPosts.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <BookOpen size={40} className="mx-auto mb-4 opacity-25" />
            <p className="text-lg font-display font-semibold mb-1">No stories found</p>
            {search
              ? <p className="text-sm">Try a different search term or clear the filter</p>
              : <p className="text-sm">Be the first to write in this category</p>
            }
            {user && (
              <button
                onClick={() => nav("create")}
                className="mt-4 text-sm font-medium text-accent hover:underline flex items-center gap-1 mx-auto"
              >
                Write a story <ArrowRight size={13} />
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map(post => (
              <PostCard key={post.id} post={post} onOpen={onOpenPost} />
            ))}
          </div>
        )}

        {/* CTA for guests */}
        {!user && (
          <div className="mt-16 bg-foreground text-primary-foreground rounded-2xl p-8 sm:p-10 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-display text-xl sm:text-2xl font-bold mb-2">Ready to share your story?</h3>
              <p className="text-primary-foreground/70 text-sm">Join Inkwell and publish your first article today.</p>
            </div>
            <div className="flex gap-3 shrink-0">
              <button
                onClick={() => nav("register")}
                className="px-6 py-2.5 bg-accent text-white rounded-full text-sm font-medium hover:opacity-85 transition-opacity"
              >
                Get Started Free
              </button>
              <button
                onClick={() => nav("login")}
                className="px-6 py-2.5 border border-white/20 text-primary-foreground/80 rounded-full text-sm hover:bg-white/10 transition-colors"
              >
                Sign In
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-border mt-16 py-8 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <PenLine size={15} className="text-accent" />
            <span className="font-display font-bold">Inkwell</span>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            A platform for thoughtful writing and genuine conversation.
          </p>
          <p className="text-xs text-muted-foreground">© 2024 Inkwell</p>
        </div>
      </footer>
    </div>
  );
}

// ─── POST DETAIL VIEW ─────────────────────────────────────────────────────────

function PostDetailView({
  post, user, users, nav, onBack, onLike, onComment, onLikeComment, onDeleteComment, onEdit, onDelete,
}: {
  post: Post; user: User | null; users: User[];
  nav: (v: View) => void; onBack: () => void;
  onLike: (postId: string) => void;
  onComment: (postId: string, content: string) => void;
  onLikeComment: (postId: string, commentId: string) => void;
  onDeleteComment: (postId: string, commentId: string) => void;
  onEdit: (postId: string) => void;
  onDelete: (postId: string) => void;
}) {
  const [commentText, setCommentText] = useState("");
  const [showDeletePost, setShowDeletePost] = useState(false);
  const isLiked = user ? post.likedBy.includes(user.id) : false;
  const isAuthor = user?.id === post.authorId;
  const authorBio = users.find(u => u.id === post.authorId)?.bio || "Writer at Inkwell.";

  function handleComment() {
    if (!commentText.trim()) return;
    onComment(post.id, commentText.trim());
    setCommentText("");
    toast.success("Comment posted!");
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Toolbar */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft size={16} />
          Back to stories
        </button>
        {isAuthor && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(post.id)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground border border-border px-3 py-1.5 rounded-lg transition-colors"
            >
              <Edit2 size={12} />
              Edit
            </button>
            <button
              onClick={() => setShowDeletePost(true)}
              className="flex items-center gap-1.5 text-sm text-red-600 hover:text-red-700 border border-red-200 px-3 py-1.5 rounded-lg transition-colors"
            >
              <Trash2 size={12} />
              Delete
            </button>
          </div>
        )}
      </div>

      {/* Hero image */}
      <div className="w-full bg-muted overflow-hidden" style={{ height: "clamp(240px, 40vh, 480px)" }}>
        <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
      </div>

      {/* Article */}
      <article className="max-w-2xl mx-auto px-4 sm:px-6 pt-10 pb-16">
        <div className="flex items-center gap-2 mb-5">
          <Badge category={post.category} />
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock size={10} />
            {readTime(post.content)} min read
          </span>
        </div>

        <h1 className="font-display text-3xl sm:text-4xl font-bold leading-tight mb-6">
          {post.title}
        </h1>

        <div className="flex items-center gap-3 pb-7 border-b border-border mb-8">
          <Avatar name={post.authorName} size={42} />
          <div>
            <div className="text-sm font-semibold">{post.authorName}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-2">
              <Calendar size={10} />
              {fmtDate(post.createdAt)}
              <span>·</span>
              <Eye size={10} />
              {post.views.toLocaleString()} views
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="space-y-5 mb-10 text-[15.5px] leading-[1.85] text-foreground/90">
          {post.content.split("\n\n").map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>

        {/* Tags */}
        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 pb-7 border-b border-border mb-7">
            {post.tags.map(tag => (
              <span key={tag} className="flex items-center gap-1 text-xs text-muted-foreground bg-muted px-3 py-1.5 rounded-full">
                <Hash size={9} />
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* Like + Share */}
        <div className="flex items-center gap-3 pb-8 border-b border-border mb-10">
          <button
            onClick={() => { if (!user) { nav("login"); return; } onLike(post.id); }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-full border transition-all text-sm font-medium ${isLiked
                ? "bg-red-50 text-red-600 border-red-200"
                : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/30"
              }`}
          >
            <Heart size={15} fill={isLiked ? "currentColor" : "none"} />
            {post.likes} {post.likes === 1 ? "like" : "likes"}
          </button>
          <button
            onClick={() => { navigator.clipboard.writeText(window.location.href); toast.success("Link copied to clipboard!"); }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full border border-border text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <Share2 size={14} />
            Share
          </button>
        </div>

        {/* Author bio */}
        <div className="bg-secondary rounded-xl p-6 mb-12 border border-border">
          <div className="flex items-start gap-4">
            <Avatar name={post.authorName} size={52} />
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="font-semibold">{post.authorName}</span>
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">Author</span>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mt-1">{authorBio}</p>
            </div>
          </div>
        </div>

        {/* Comments section */}
        <div>
          <h2 className="font-display text-xl font-semibold mb-6 flex items-center gap-2">
            <MessageCircle size={18} />
            {post.comments.length} {post.comments.length === 1 ? "Comment" : "Comments"}
          </h2>

          {/* Add comment */}
          {user ? (
            <div className="flex gap-3 mb-8">
              <Avatar name={user.name} size={36} />
              <div className="flex-1">
                <textarea
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  placeholder="Share your thoughts on this story..."
                  rows={3}
                  className="w-full px-4 py-3 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent resize-none transition-all"
                />
                <div className="flex justify-end mt-2">
                  <button
                    onClick={handleComment}
                    disabled={!commentText.trim()}
                    className="text-sm font-medium bg-foreground text-primary-foreground px-5 py-2 rounded-full disabled:opacity-40 hover:opacity-85 transition-opacity"
                  >
                    Post Comment
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-muted border border-border rounded-xl p-5 mb-8 text-center">
              <p className="text-sm text-muted-foreground mb-3">Sign in to join the conversation</p>
              <button
                onClick={() => nav("login")}
                className="inline-flex items-center gap-2 text-sm font-medium bg-foreground text-primary-foreground px-5 py-2 rounded-full hover:opacity-85 transition-opacity"
              >
                <LogIn size={14} />
                Sign In to Comment
              </button>
            </div>
          )}

          {/* Comments list */}
          {post.comments.length > 0 ? (
            <div className="space-y-7">
              {post.comments.map(comment => (
                <CommentItem
                  key={comment.id}
                  comment={comment}
                  user={user}
                  onLike={() => onLikeComment(post.id, comment.id)}
                  onDelete={() => { onDeleteComment(post.id, comment.id); toast.success("Comment deleted"); }}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-muted-foreground border border-border rounded-xl bg-muted/30">
              <MessageCircle size={28} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">No comments yet. Be the first to respond!</p>
            </div>
          )}
        </div>
      </article>

      {showDeletePost && (
        <ConfirmModal
          title="Delete this post?"
          description="This action cannot be undone. The post and all its comments will be permanently removed."
          confirmLabel="Delete Post"
          onConfirm={() => { onDelete(post.id); toast.success("Post deleted"); }}
          onCancel={() => setShowDeletePost(false)}
        />
      )}
    </div>
  );
}

// ─── AUTH FIELD ───────────────────────────────────────────────────────────────

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      {children}
    </div>
  );
}

const inputClass = "w-full px-4 py-2.5 text-sm border border-border rounded-lg bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent transition-all";

// ─── LOGIN VIEW ───────────────────────────────────────────────────────────────

function LoginView({ onLogin, nav }: { onLogin: (email: string, password: string) => boolean; nav: (v: View) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      const ok = onLogin(email.trim(), password);
      if (!ok) setError("Invalid email or password. Try a demo account below.");
      setLoading(false);
    }, 650);
  }

  return (
    <div className="min-h-screen bg-background flex">
      <div className="flex-1 flex items-center justify-center px-4 sm:px-8 lg:px-16 py-12">
        <div className="w-full max-w-sm">
          <button
            onClick={() => nav("home")}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ChevronLeft size={15} />
            Back to Inkwell
          </button>

          <div className="flex items-center gap-2 mb-7">
            <PenLine size={20} className="text-accent" />
            <span className="font-display text-xl font-bold">Inkwell</span>
          </div>

          <h1 className="font-display text-3xl font-bold mb-1">Welcome back</h1>
          <p className="text-sm text-muted-foreground mb-7">Sign in to continue writing and reading</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field label="Email address">
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required className={inputClass} />
            </Field>
            <Field label="Password">
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required className={inputClass} />
            </Field>
            {error && (
              <div className="flex items-center gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2.5">
                <AlertCircle size={13} className="shrink-0" />
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-foreground text-primary-foreground py-2.5 rounded-lg text-sm font-medium hover:opacity-85 transition-opacity disabled:opacity-50 mt-1"
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          <p className="text-sm text-center text-muted-foreground mt-6">
            {"Don't have an account? "}
            <button onClick={() => nav("register")} className="text-foreground font-semibold hover:underline">
              Create one
            </button>
          </p>

          <div className="mt-6 p-4 bg-muted rounded-xl border border-border">
            <p className="text-xs font-semibold text-foreground mb-2">Demo accounts</p>
            <div className="space-y-1.5">
              <button
                onClick={() => { setEmail("sarah@inkwell.com"); setPassword("password123"); }}
                className="block w-full text-left text-xs text-muted-foreground hover:text-foreground transition-colors bg-card rounded-lg px-3 py-2 border border-border"
              >
                sarah@inkwell.com · password123
              </button>
              <button
                onClick={() => { setEmail("marcus@inkwell.com"); setPassword("password123"); }}
                className="block w-full text-left text-xs text-muted-foreground hover:text-foreground transition-colors bg-card rounded-lg px-3 py-2 border border-border"
              >
                marcus@inkwell.com · password123
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="hidden lg:block w-[45%] relative bg-slate-900">
        <img
          src="https://images.unsplash.com/photo-1504691342899-4d92b50853e1?w=800&h=1100&fit=crop&auto=format"
          alt="Writing desk with laptop"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/30 to-black/50" />
        <div className="absolute bottom-12 left-10 right-10 text-white">
          <p className="font-display text-2xl font-semibold italic leading-snug mb-3">
            "The art of writing is the art of discovering what you believe."
          </p>
          <p className="text-sm text-white/55">— Gustave Flaubert</p>
        </div>
      </div>
    </div>
  );
}

// ─── REGISTER VIEW ────────────────────────────────────────────────────────────

function RegisterView({
  onRegister, nav,
}: {
  onRegister: (name: string, email: string, password: string, bio: string) => boolean;
  nav: (v: View) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bio, setBio] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password.length < 6) { setError("Password must be at least 6 characters"); return; }
    setLoading(true);
    setTimeout(() => {
      const ok = onRegister(name, email, password, bio);
      if (!ok) setError("An account with this email already exists.");
      setLoading(false);
    }, 700);
  }

  return (
    <div className="min-h-screen bg-background flex">
      <div className="flex-1 flex items-center justify-center px-4 sm:px-8 lg:px-16 py-12">
        <div className="w-full max-w-sm">
          <button
            onClick={() => nav("home")}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ChevronLeft size={15} />
            Back to Inkwell
          </button>

          <div className="flex items-center gap-2 mb-7">
            <PenLine size={20} className="text-accent" />
            <span className="font-display text-xl font-bold">Inkwell</span>
          </div>

          <h1 className="font-display text-3xl font-bold mb-1">Create your account</h1>
          <p className="text-sm text-muted-foreground mb-7">Join thousands of writers and readers</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field label="Full Name">
              <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Jane Smith" required className={inputClass} />
            </Field>
            <Field label="Email address">
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required className={inputClass} />
            </Field>
            <Field label="Password">
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Min. 6 characters" required minLength={6} className={inputClass} />
            </Field>
            <Field label="Bio (optional)">
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                placeholder="Tell us a little about yourself..."
                rows={2}
                className={`${inputClass} resize-none`}
              />
            </Field>
            {error && (
              <div className="flex items-center gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2.5">
                <AlertCircle size={13} className="shrink-0" />
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-foreground text-primary-foreground py-2.5 rounded-lg text-sm font-medium hover:opacity-85 transition-opacity disabled:opacity-50 mt-1"
            >
              {loading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <p className="text-sm text-center text-muted-foreground mt-6">
            Already have an account?{" "}
            <button onClick={() => nav("login")} className="text-foreground font-semibold hover:underline">
              Sign in
            </button>
          </p>
        </div>
      </div>

      <div className="hidden lg:block w-[45%] relative bg-slate-900">
        <img
          src="https://images.unsplash.com/photo-1663505467708-7890d36d0c59?w=800&h=1100&fit=crop&auto=format"
          alt="Person writing at laptop"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-black/55" />
        <div className="absolute bottom-12 left-10 right-10 text-white">
          <p className="font-display text-2xl font-semibold italic leading-snug mb-3">
            "A writer only begins a book. A reader finishes it."
          </p>
          <p className="text-sm text-white/55">— Samuel Johnson</p>
        </div>
      </div>
    </div>
  );
}

// ─── POST FORM (shared by Create & Edit) ─────────────────────────────────────

function PostForm({
  initialValues,
  onSubmit,
  nav,
  heading,
  submitLabel,
  backTarget,
}: {
  initialValues: {
    title: string; excerpt: string; content: string;
    category: string; tags: string; image: string;
  };
  onSubmit: (data: { title: string; excerpt: string; content: string; category: string; tags: string[]; image: string }) => void;
  nav: (v: View) => void;
  heading: string;
  submitLabel: string;
  backTarget: View;
}) {
  const [title, setTitle] = useState(initialValues.title);
  const [excerpt, setExcerpt] = useState(initialValues.excerpt);
  const [content, setContent] = useState(initialValues.content);
  const [category, setCategory] = useState(initialValues.category);
  const [tags, setTags] = useState(initialValues.tags);
  const [image, setImage] = useState(initialValues.image);
  const [imgError, setImgError] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !content.trim()) { toast.error("Title and content are required"); return; }
    setSubmitting(true);
    setTimeout(() => {
      onSubmit({
        title: title.trim(),
        excerpt: excerpt.trim() || content.trim().slice(0, 180).replace(/\n/g, " ") + "...",
        content: content.trim(),
        category,
        tags: tags.split(",").map(t => t.trim().toLowerCase().replace(/\s+/g, "-")).filter(Boolean),
        image: image.trim() || "https://images.unsplash.com/photo-1560092057-552a70533807?w=800&h=500&fit=crop&auto=format",
      });
      setSubmitting(false);
    }, 800);
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => nav(backTarget)}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ChevronLeft size={15} />
            Back
          </button>
          <h1 className="font-display text-xl font-bold">{heading}</h1>
          <div className="w-12" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <Field label="Title *">
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Give your story a compelling title..."
              required
              className="w-full px-4 py-3 text-base font-display border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent transition-all"
            />
          </Field>

          <Field label="Excerpt">
            <textarea
              value={excerpt}
              onChange={e => setExcerpt(e.target.value)}
              placeholder="A brief summary shown in the post list (auto-generated if left empty)..."
              rows={2}
              className="w-full px-4 py-3 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent resize-none transition-all"
            />
          </Field>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Category *">
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full px-4 py-2.5 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent cursor-pointer"
              >
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Tags (comma-separated)">
              <input
                type="text"
                value={tags}
                onChange={e => setTags(e.target.value)}
                placeholder="writing, tips, productivity"
                className="w-full px-4 py-2.5 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent transition-all"
              />
            </Field>
          </div>

          <Field label="Cover Image URL">
            <input
              type="url"
              value={image}
              onChange={e => { setImage(e.target.value); setImgError(false); }}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-4 py-2.5 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent transition-all"
            />
            {image && !imgError && (
              <div className="mt-2 h-36 rounded-xl overflow-hidden bg-muted border border-border">
                <img
                  src={image}
                  alt="Cover preview"
                  className="w-full h-full object-cover"
                  onError={() => setImgError(true)}
                />
              </div>
            )}
            {image && imgError && (
              <p className="mt-1.5 text-xs text-amber-700">Could not load this image URL. Please check the link.</p>
            )}
          </Field>

          <Field label="Content *">
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={`Write your story here...\n\nUse two line breaks to separate paragraphs.`}
              rows={18}
              required
              className="w-full px-4 py-3 text-sm border border-border rounded-xl bg-card focus:outline-none focus:ring-2 focus:ring-accent/25 focus:border-accent resize-none leading-relaxed transition-all"
            />
            <p className="mt-1 text-xs text-muted-foreground text-right">
              {content.split(/\s+/).filter(Boolean).length} words · ~{readTime(content)} min read
            </p>
          </Field>

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 bg-foreground text-primary-foreground py-3 rounded-xl text-sm font-medium hover:opacity-85 transition-opacity disabled:opacity-50"
            >
              {submitting ? "Saving..." : submitLabel}
            </button>
            <button
              type="button"
              onClick={() => nav(backTarget)}
              className="px-6 py-3 border border-border rounded-xl text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── DASHBOARD VIEW ───────────────────────────────────────────────────────────

function DashboardView({
  user, posts, nav, onEdit, onDeletePost,
}: {
  user: User; posts: Post[]; nav: (v: View) => void;
  onEdit: (id: string) => void; onDeletePost: (id: string) => void;
}) {
  const userPosts = posts.filter(p => p.authorId === user.id);
  const totalViews = userPosts.reduce((s, p) => s + p.views, 0);
  const totalLikes = userPosts.reduce((s, p) => s + p.likes, 0);
  const totalComments = userPosts.reduce((s, p) => s + p.comments.length, 0);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const stats = [
    { label: "Stories", value: userPosts.length, icon: FileText },
    { label: "Total Views", value: totalViews.toLocaleString(), icon: Eye },
    { label: "Total Likes", value: totalLikes, icon: Heart },
    { label: "Comments", value: totalComments, icon: MessageCircle },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
        {/* Profile header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10 pb-8 border-b border-border">
          <div className="flex items-center gap-4">
            <Avatar name={user.name} size={56} />
            <div>
              <h1 className="font-display text-2xl font-bold">{user.name}</h1>
              <p className="text-sm text-muted-foreground">{user.email}</p>
              {user.bio && <p className="text-sm text-muted-foreground mt-1 max-w-md line-clamp-1">{user.bio}</p>}
            </div>
          </div>
          <button
            onClick={() => nav("create")}
            className="flex items-center gap-2 bg-foreground text-primary-foreground px-5 py-2.5 rounded-full text-sm font-medium hover:opacity-85 transition-opacity shrink-0"
          >
            <Plus size={14} />
            New Story
          </button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
          {stats.map(({ label, value, icon: Icon }) => (
            <div key={label} className="bg-card border border-border rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Icon size={14} className="text-muted-foreground" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</span>
              </div>
              <div className="font-display text-2xl font-bold">{value}</div>
            </div>
          ))}
        </div>

        {/* Posts table */}
        <div>
          <h2 className="font-display text-xl font-semibold mb-5">Your Stories</h2>

          {userPosts.length === 0 ? (
            <div className="text-center py-16 bg-card border border-border rounded-2xl">
              <PenLine size={36} className="mx-auto mb-3 text-muted-foreground opacity-30" />
              <p className="text-muted-foreground mb-1 font-display font-semibold">No stories yet</p>
              <p className="text-sm text-muted-foreground mb-5">Start writing to share your ideas with the world</p>
              <button
                onClick={() => nav("create")}
                className="inline-flex items-center gap-2 text-sm font-medium text-accent hover:underline"
              >
                Write your first story <ArrowRight size={13} />
              </button>
            </div>
          ) : (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-muted/40">
                      <th className="text-left text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-5 py-3">Title</th>
                      <th className="text-left text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-4 py-3 hidden sm:table-cell">Category</th>
                      <th className="text-left text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-4 py-3 hidden md:table-cell">Date</th>
                      <th className="text-right text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-5 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {userPosts.map(post => (
                      <tr key={post.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-5 py-4">
                          <div className="text-sm font-medium line-clamp-1 max-w-[280px]">{post.title}</div>
                          <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-3">
                            <span className="flex items-center gap-1"><Eye size={9} />{post.views.toLocaleString()}</span>
                            <span className="flex items-center gap-1"><Heart size={9} />{post.likes}</span>
                            <span className="flex items-center gap-1"><MessageCircle size={9} />{post.comments.length}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 hidden sm:table-cell">
                          <Badge category={post.category} />
                        </td>
                        <td className="px-4 py-4 text-xs text-muted-foreground hidden md:table-cell whitespace-nowrap">
                          {fmtDate(post.createdAt)}
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => onEdit(post.id)}
                              className="text-xs text-muted-foreground hover:text-foreground border border-border px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
                            >
                              <Edit2 size={10} />
                              Edit
                            </button>
                            <button
                              onClick={() => setDeleteId(post.id)}
                              className="text-xs text-red-600 hover:text-red-700 border border-red-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
                            >
                              <Trash2 size={10} />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {deleteId && (
        <ConfirmModal
          title="Delete this story?"
          description="This cannot be undone. The story and all its comments will be permanently removed."
          confirmLabel="Delete Story"
          onConfirm={() => {
            onDeletePost(deleteId);
            setDeleteId(null);
            toast.success("Story deleted");
          }}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [users, setUsers] = useState<User[]>(() => loadState("inkwell_users", INITIAL_USERS));
  const [posts, setPosts] = useState<Post[]>(() => loadState("inkwell_posts", INITIAL_POSTS));
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadState("inkwell_user", null));
  const [view, setView] = useState<View>("home");
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [editingPostId, setEditingPostId] = useState<string | null>(null);

  useEffect(() => { localStorage.setItem("inkwell_users", JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem("inkwell_posts", JSON.stringify(posts)); }, [posts]);
  useEffect(() => {
    if (currentUser) localStorage.setItem("inkwell_user", JSON.stringify(currentUser));
    else localStorage.removeItem("inkwell_user");
  }, [currentUser]);

  function nav(v: View) {
    setView(v);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function openPost(postId: string) {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, views: p.views + 1 } : p));
    setSelectedPostId(postId);
    nav("post");
  }

  function handleLogin(email: string, password: string) {
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      setCurrentUser(user);
      toast.success(`Welcome back, ${user.name.split(" ")[0]}!`);
      nav("home");
      return true;
    }
    return false;
  }

  function handleRegister(name: string, email: string, password: string, bio: string) {
    if (users.find(u => u.email === email)) return false;
    const newUser: User = {
      id: uid(), name: name.trim(), email: email.trim(),
      password, bio: bio.trim(), joinedAt: new Date().toISOString().slice(0, 10),
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    toast.success(`Welcome to Inkwell, ${name.split(" ")[0]}!`);
    nav("home");
    return true;
  }

  function handleLogout() {
    setCurrentUser(null);
    nav("home");
    toast.success("Signed out. See you next time!");
  }

  function handleLikePost(postId: string) {
    if (!currentUser) return;
    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      const liked = p.likedBy.includes(currentUser.id);
      return { ...p, likes: liked ? p.likes - 1 : p.likes + 1, likedBy: liked ? p.likedBy.filter(id => id !== currentUser.id) : [...p.likedBy, currentUser.id] };
    }));
  }

  function handleAddComment(postId: string, content: string) {
    if (!currentUser) return;
    const comment: Comment = {
      id: uid(), postId, authorId: currentUser.id, authorName: currentUser.name,
      content, createdAt: new Date().toISOString(), likes: 0, likedBy: [],
    };
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, comments: [...p.comments, comment] } : p));
  }

  function handleLikeComment(postId: string, commentId: string) {
    if (!currentUser) return;
    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      return {
        ...p, comments: p.comments.map(c => {
          if (c.id !== commentId) return c;
          const liked = c.likedBy.includes(currentUser.id);
          return { ...c, likes: liked ? c.likes - 1 : c.likes + 1, likedBy: liked ? c.likedBy.filter(id => id !== currentUser.id) : [...c.likedBy, currentUser.id] };
        }),
      };
    }));
  }

  function handleDeleteComment(postId: string, commentId: string) {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, comments: p.comments.filter(c => c.id !== commentId) } : p));
  }

  function handleCreatePost(data: { title: string; excerpt: string; content: string; category: string; tags: string[]; image: string }) {
    if (!currentUser) return;
    const newPost: Post = {
      id: uid(), ...data,
      authorId: currentUser.id, authorName: currentUser.name,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      views: 0, likes: 0, likedBy: [], comments: [], featured: false,
    };
    setPosts(prev => [newPost, ...prev]);
    toast.success("Story published!");
    nav("dashboard");
  }

  function handleUpdatePost(postId: string, data: { title: string; excerpt: string; content: string; category: string; tags: string[]; image: string }) {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, ...data, updatedAt: new Date().toISOString() } : p));
    setEditingPostId(null);
    toast.success("Story updated!");
    nav("dashboard");
  }

  function handleDeletePost(postId: string) {
    setPosts(prev => prev.filter(p => p.id !== postId));
    if (selectedPostId === postId) { setSelectedPostId(null); nav("home"); }
  }

  function startEdit(postId: string) {
    setEditingPostId(postId);
    nav("edit");
  }

  const selectedPost = posts.find(p => p.id === selectedPostId);
  const editingPost = posts.find(p => p.id === editingPostId);

  // Guard: redirect protected routes
  useEffect(() => {
    if ((view === "create" || view === "edit" || view === "dashboard") && !currentUser) {
      nav("login");
    }
  }, [view, currentUser]);

  return (
    <>
      <Toaster position="top-right" richColors closeButton />

      {view !== "login" && view !== "register" && (
        <Navbar user={currentUser} nav={nav} onLogout={handleLogout} />
      )}

      {view === "home" && (
        <HomeView posts={posts} user={currentUser} nav={nav} onOpenPost={openPost} />
      )}

      {view === "post" && selectedPost ? (
        <PostDetailView
          post={selectedPost}
          user={currentUser}
          users={users}
          nav={nav}
          onBack={() => nav("home")}
          onLike={handleLikePost}
          onComment={handleAddComment}
          onLikeComment={handleLikeComment}
          onDeleteComment={handleDeleteComment}
          onEdit={startEdit}
          onDelete={handleDeletePost}
        />
      ) : view === "post" ? (
        <div className="min-h-screen flex items-center justify-center text-muted-foreground">
          Post not found. <button onClick={() => nav("home")} className="ml-2 text-accent hover:underline">Go home</button>
        </div>
      ) : null}

      {view === "login" && (
        <LoginView onLogin={handleLogin} nav={nav} />
      )}

      {view === "register" && (
        <RegisterView onRegister={handleRegister} nav={nav} />
      )}

      {view === "create" && currentUser && (
        <PostForm
          heading="Write a Story"
          submitLabel="Publish Story"
          backTarget="home"
          initialValues={{ title: "", excerpt: "", content: "", category: "Technology", tags: "", image: "" }}
          onSubmit={handleCreatePost}
          nav={nav}
        />
      )}

      {view === "edit" && editingPost && currentUser ? (
        <PostForm
          heading="Edit Story"
          submitLabel="Save Changes"
          backTarget="dashboard"
          initialValues={{
            title: editingPost.title,
            excerpt: editingPost.excerpt,
            content: editingPost.content,
            category: editingPost.category,
            tags: editingPost.tags.join(", "),
            image: editingPost.image,
          }}
          onSubmit={(data) => handleUpdatePost(editingPost.id, data)}
          nav={nav}
        />
      ) : view === "edit" && !editingPost ? (
        <div className="min-h-screen flex items-center justify-center text-muted-foreground">
          Post not found. <button onClick={() => nav("dashboard")} className="ml-2 text-accent hover:underline">Go to dashboard</button>
        </div>
      ) : null}

      {view === "dashboard" && currentUser && (
        <DashboardView
          user={currentUser}
          posts={posts}
          nav={nav}
          onEdit={startEdit}
          onDeletePost={handleDeletePost}
        />
      )}
    </>
  );
}
