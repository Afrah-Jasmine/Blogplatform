
  # Blogging Platform with Comments

  This is a code bundle for Blogging Platform with Comments. The original project is available at https://www.figma.com/design/7X6h4jOKq3DCgnXSq2kTX3/Blogging-Platform-with-Comments.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  